﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    class Program
    {


        public class temp : Exception
        {
            public temp (string message)
            
            :base (message)
            {}
        
        }


        public class temperature
        {
            public void showToTemp()
            {
                Console.WriteLine("enter temperature");
                    int temperature = Convert.ToInt32(Console.ReadLine());

                if(temperature==1){
                    throw(new temp("temoerature can not be one"));
                }
                else{
                    Console.WriteLine("temperature" + temperature);
                }
            }
        }

        








        static void Main(string[] args)
        {
            temperature temper = new temperature();
            try
            {
                temper.showToTemp();
            }
            catch(temp e)
            {
                Console.WriteLine("temper is zero:{}", e.Message);
            }
            Console.ReadLine();
        }
    }
}
